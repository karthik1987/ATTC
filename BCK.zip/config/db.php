<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=naethra1_attc',
    'username' => 'naethra1_attc',
    'password' => 'Login@123',
    'charset' => 'utf8',
];
